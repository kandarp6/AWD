# TODO - Practical 5 Implementation

## Tasks:
- [ ] Update pr5/src/app/app.config.ts - Add HttpClient provider
- [ ] Update pr5/src/app/app.ts - Add Angular component with HTTP client
- [ ] Update pr5/src/app/app.html - Add HTML table template
- [ ] Update pr5/src/app/app.css - Add CSS styles
- [ ] Create pr5/Customers.php - PHP file with JSON data

## Status: In Progress
